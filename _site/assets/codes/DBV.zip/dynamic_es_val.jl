using JuMP
using Gurobi
using MAT
using Printf

# Specify price zone name
Zone = "NORTH"

# read price data
fileln = matopen(string("./data/RTP_",Zone,"_2010_2019.mat"))
RTP = read(fileln, "RTP")
close(fileln)

# energy storage rating specifications
E = 2;  # storage energy capacity in MWh
P = 1; # power rating MW
# E = 2; # energy rating MWh8
eta = .922; # single-trip efficiency
e0 = .5 * E;
ef = e0;

# warranty info
P_recycle = 2e5; # recycle value per MWh
EoW = .2; # end of warranty

# battery degradation specifications
Ycal = 5; # calendar life
m = 2; # nonlinear degradation coefficient
J = 4; # number of de0gradation model segme nts
EoL = .40; # End of life
# 10 year one full cycle per day to 70% capacity, 20 year calendar life to 70%
# Ycal = 10;
dD_cal = EoW/365/Ycal; # calendar degradation per day
# N = 365 * Ycal/2; # number of cycles till end of life
N = 1000; # energy throughput befor reaching 80%
N_d = .8; # depth of cycle for cycle life
# m = 1; # nonlinear coefficient
k = EoW/(N*N_d.^m); # cycle life coefficient
# J = 1; # number of piece-wise linearzition blocks
# c_pu = m*k*((1:J)/J).^(m-1); # normalized piece-wise linear cycle cost
c_pu = (J/E) * (k * (Vector(1:J)/J).^m - k*(Vector(0:(J-1))/J).^m)



# initialize storage value function
Ds = 0:.01:EoL;
nV = length(Ds);
global Vs = zeros(1,nV)
Vs[1:21] = P_recycle*E*(1 .- Ds[1:21]).*LinRange(1,0,21);
Vs0 = Vs;


# simulation setting
T = 288; # time step per day
M = 1/12; # duaration per step in hour
N_sim = 3650; # number of days


# daily discount ratio
disR = 0.92^(1/365);

# degradation self-dependency and piece-wise linear setting
alpha = 5.75e-2; # self-dependency coef
beta = 121; # self-dependency coef
dD = .01; # degradation samping step
# nV = 31; # number of steps
# nonlinear degradation coefficient
dc = alpha * (beta) * exp.(-beta * Ds) + (1-alpha) * exp.(-Ds);


# initialize auxilliary variables for optimization
D0 = 0
dDC = dD_cal;
L = RTP[:,1]

# initialize optimization model
model = Model(Gurobi.Optimizer)
set_silent(model) # no outputs
# discharge segments
@variable(model, p_d[1:T, 1:J], lower_bound = 0 )
# charge segments
@variable(model, p_c[1:T, 1:J], lower_bound = 0  )
# energy level segments
@variable(model, e_b[1:T, 1:J], lower_bound = 0  )
# initial energy level segments
@variable(model, e_i[1:J], lower_bound = 0  )
# total discharge power
@variable(model, d[1:T])
# total charge power
@variable(model, c[1:T])
# total energy level
@variable(model, e[1:T])
@variable(model, D) # incremental cycle degradation
@variable(model, C) # value of battery capacity at the end of operation
@variable(model, R) # market revenue

# arbitrage revenue
@constraint(model, ArbRev, R == M*sum(L.*(d-c)) )
# degradation increments
@constraint(model, DegInc, D - M*sum(c_pu.*sum(p_d, dims = 1) ) == D0  + dDC)
# piece-wise linear degradation opportunity value
@constraint(model, DegCost, C .<= Vs[1] + (D-Ds[1]) * (Vs[1]-Vs[2]) / (Ds[1]-Ds[2])  )
# initial SoC evolution
@constraint(model, SoCInit[j = 1:J], e_b[1,j] - e_i[j] == M*(p_c[1,j] - p_d[1,j]) )
# rest SoC evolution
@constraint(model, SoCCont[t = 2:T, j = 1:J], e_b[t,j] - e_b[t-1,j] == M*(p_c[t,j] - p_d[t,j]) )
# discharge power segment logic
@constraint(model, DisSeg[t=1:T], d[t] == sum(p_d[t,:]) * eta )
# charge power segment logic
@constraint(model, ChrSeg[t=1:T], c[t] == sum(p_c[t,:]) / eta )
# SoC segment logic
@constraint(model, SoCSeg[t=1:T], e[t] == sum(e_b[t,:])  )
# initial energy level
@constraint(model, Eneinit, sum(e_i) == e0 )
# final energy level
@constraint(model, Enelast, e[T] >= ef )
# max discharge power
@constraint(model, DisMax[t=1:T], d[t] <= P )
# max charge power
@constraint(model, ChrMax[t=1:T], c[t] <= P )
# max energy level
@constraint(model, SoCMax[t=1:T, j = 1:J], e_b[t,j] <= (E-E*D0)/J )
# warranty constraint
# @constraint(model, ETHMax, M*sum(d)/eta <= E-E*D0 )

# maximize revenue plus degradation value
@objective(model, Max, R+disR*C)

# perform a initialization run
optimize!(model)

# initialize value function record
V_s = zeros(nV, N_sim)

@printf("Optimization starts...\n")
for n = 1:N_sim


# update prices
local L = RTP[:,N_sim+1-n]

# update prices in constraints
for t = 1:T
    set_normalized_coefficient(ArbRev, d[t], -M*L[t] )
    set_normalized_coefficient(ArbRev, c[t], M*L[t] )
end

# update piecewise linear
# for i = 1:(nV-1)
#     set_normalized_coefficient(DegCost[i], D, -(Vs[i]-Vs[i+1]) / (Ds[i]-Ds[i+1]) )
#     set_normalized_rhs(DegCost[i],  Vs[i]-Ds[i]*(Vs[i]-Vs[i+1]) / (Ds[i]-Ds[i+1]) )
# end

for i = 1:(nV-1)

set_normalized_coefficient(DegCost, D, -(Vs[i]-Vs[i+1]) / (Ds[i]-Ds[i+1]) )
set_normalized_rhs(DegCost,  Vs[i]-Ds[i]*(Vs[i]-Vs[i+1]) / (Ds[i]-Ds[i+1]) )

# update degradation constraints
set_normalized_rhs(DegInc, Ds[i] +  dD_cal)
for t = 1:T
    for j = 1:J
        set_normalized_coefficient(DegInc, p_d[t,j], -M*c_pu[j])
        set_normalized_rhs(SoCMax[t,j], (E-E*Ds[i])/J )
    end
end

optimize!(model)

global V_s[i,n] = max(Vs0[i], objective_value(model))

end

# update value function
global Vs = V_s[:,n]

@printf("Finished Day %d, New battery value %.2f, OptStatus: %s \n", n, Vs[1], termination_status(model))

end

# save results
if m == 1
    FN = @sprintf("H%d_L%d_P%d_TR_SL", E, EoL*100, P_recycle/1e4)
else
    FN = @sprintf("H%d_L%d_P%d_SL", E, EoL*100, P_recycle/1e4)
end

file = matopen(string("./results_mat/",Zone,"2010_2019_",FN,".mat"), "w")
write(file, "Vs", collect(Vs))
write(file, "V_s", collect(V_s))
write(file, "Ds", collect(Ds))
write(file, "E", E)
write(file, "P", P)
write(file, "eta", eta)
write(file, "J", J)
write(file, "Ycal", Ycal)
write(file, "P_recycle", P_recycle)
write(file, "Vs0", Vs0)
write(file, "EoL", EoL)
write(file, "EoW", EoW)
close(file)
