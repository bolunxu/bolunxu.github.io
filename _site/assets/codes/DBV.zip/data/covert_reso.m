load('RTP_LONGIL_2010_2019.mat')

RTP_h = zeros(24,size(RTP,2));

for h = 1:24
   RTP_h(h,:) = mean(RTP((1:12)+12*(h-1),:)); 
end