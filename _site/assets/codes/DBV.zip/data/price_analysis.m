load('RTP_NYC_2010_2019.mat')
RTP_Y = RTP;
load('RTP_LONGIL_2010_2019.mat')
RTP_L = RTP;
load('RTP_NORTH_2010_2019.mat')
RTP_N = RTP;
load('RTP_WEST_2010_2019.mat')
RTP_W = RTP;


YY = linspace(2010, 2020, 3650);

figure('Position', [200 200 600 200])
hold all
plot(YY, movmean(mean(RTP_L),365), '-.', 'LineWidth', 1.5)
plot(YY, movmean(mean(RTP_Y),365), ':', 'LineWidth', 1.5)
plot(YY, movmean(mean(RTP_W),365), '-', 'LineWidth', 1.5)
plot(YY, movmean(mean(RTP_N),365), '--', 'LineWidth', 2)
grid on
% xlabel('Year')
ylabel('$/MWh')
ylim([15 90])
legend({'LONGIL', 'NYC', 'WEST', 'NORTH'}, 'FontSize', 14, 'Orientation', 'horizontal')

figure('Position', [200 200 600 200])
hold all
plot(YY, movmean(std(RTP_L),365), '-.', 'LineWidth', 1.5)
plot(YY, movmean(std(RTP_Y),365), ':', 'LineWidth', 1.5)
plot(YY, movmean(std(RTP_W),365), '-', 'LineWidth', 1.5)
plot(YY, movmean(std(RTP_N),365), '--','LineWidth', 2)
grid on
% xlabel('Year')
ylabel('$/MWh')
ylim([15 90])
legend({'LONGIL', 'NYC', 'WEST', 'NORTH'}, 'FontSize', 14, 'Orientation', 'horizontal')

%%

figure('Position', [200 200 600 200])
hold all
% plot(YY, movmean(mean(RTP_L),365), '-.', 'LineWidth', 1.5)
% plot(YY, movmean(mean(RTP_Y),365), '-', 'LineWidth', 2)
plot(YY, movmean(mean(RTP_W),365), '-', 'LineWidth', 1.5)
% plot(YY, movmean(mean(RTP_N),365), '--', 'LineWidth', 2)
grid on
% xlabel('Year')
ylabel('$/MWh')
% ylim([15 90])
% legend({'LONGIL', 'NYC', 'WEST', 'NORTH'}, 'FontSize', 14, 'Orientation', 'horizontal')

figure('Position', [200 200 600 200])
hold all
% plot(YY, movmean(std(RTP_L),365), '-.', 'LineWidth', 1.5)
% plot(YY, movmean(std(RTP_Y),365), '-', 'LineWidth', 2)
plot(YY, movmean(std(RTP_W),365), '-', 'LineWidth', 1.5)
% plot(YY, movmean(std(RTP_N),365), '--','LineWidth', 2)
grid on
% xlabel('Year')
ylabel('$/MWh')
% ylim([15 90])
% legend({'LONGIL', 'NYC', 'WEST', 'NORTH'}, 'FontSize', 14, 'Orientation', 'horizontal')
%%
figure('Position', [200 200 600 200])
hold all
plot(YY, movmean(std(RTP_L),720), '-', 'LineWidth', 2)
grid on
% xlabel('Year')
ylabel('$/MWh', 'FontSize', 14)
ylim([15 90])
% legend({'LONGIL', 'NYC', 'WEST', 'NORTH'}, 'FontSize', 14, 'Orientation', 'horizontal')


%%

DD = linspace(2010, 2020, 3650*288);
figure('Position', [200 200 600 200])
hold all
plot(DD, RTP(:))
grid on
% xlabel('Year')
ylabel('$/MWh')