load('RTP_WEST_2010_2019.mat')

ND = size(RTP, 2);


NT = size(RTP, 1);

T = cell(size(RTP)+1);

for i = 1:ND
T{1, i+1} = sprintf('Day%d', i); 
end

for i = 1:NT
T{i+1,1} = sprintf('Step%d', i); 
end

T(2:end, 2:end) = num2cell(RTP);

writetable(T, 'RTP_WEST_2010_2019.csv')