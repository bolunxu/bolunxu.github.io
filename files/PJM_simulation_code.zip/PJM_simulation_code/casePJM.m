%% 
% This is the simulation code for the PJM case study in the paper
% https://arxiv.org/pdf/1710.10514.pdf

% Author: Bolun Xu
% Institution (where this work is completed): University of Washington
% Contact: bolunxu.github.io

% Note: the simulation is reduced to 1 week to reduce the file size. 

%% set up
gamma = .008; % this is a key design parameter, see paper for what gamma means
rhoMin = .7; % the minimum performance requirement

% 0 - use proposed policy
% 1 - use benchmark policy
isSimple = 0; 

B = 10; % MW, storage power capacity
E = 3; % MWh, storage energy capacity
socMax = .95; % maximum SoC
socMin = .1; % minimum SoC
EMax = socMax*E;
EMin = socMin*E;
eta = .92; % efficiency
m = 2.03; % degradation function nonlinear factor
N = 1000; % number of cycles at 80% DoD
alpha = 1./(N*.8^m); 
R = 300e3; % cell replacement cost $/MWh
delta = 1/3; % coefficient for performance calculation, see paper
uR = 300; % expected total instruction in MW*(2 seconds)
uM = 3; % expected mileage factor
T = 2/3600; % time resolution
soc0 = .5; % initial SoC

CMax = min(B, (EMax-EMin)/gamma);

% bidding segments
Cb = ones(10,1);
% initialzie price
Lb = zeros(10,1);

% calculate bid price associated with each segment
for j = 1:length(Cb)
  cc = sum(Cb(1:j));
  ll = m*alpha*(cc*gamma/E)^(m-1)*(eta*R*uR*T)/((eta^2+1)*delta);
  Lb(j) = ll*cc - sum(Lb(1:(j-1)).*Cb(1:(j-1)));
end


%%
% load and clean up data 
load('PJM_RegD_1week')
D(isnan(D)) = 0;
D = reshape(D(1:(end-1),:), numel(D(1:(end-1),:)), 1);
L = length(D);

nH = floor(L/(1/T));
H = 1/T; % number of samples per hour

% initialize performance records
rhoM = zeros(floor(L/(1/T)),1);
rhoMA = rhoM;
rhoMD = rhoM;
rhoMP = rhoM;

% load system price data
load('PJM_Reg_Price_201603_201702')
load('PJM_Reg_Mileage_201603_201702')
mRatio = milD./milA;
mRatio(isnan(mRatio)) = 0;
mRatio(mRatio > 5) = 5;

% calculate expected market prices
uL = CCP + uM * PCP;

% calculate cleared capacity from the bidding policy
Cc = zeros(nH,length(Cb));

for j = 1:length(Cb)
  Cc(:,j) = uL > Lb(j);
end

C = sum(Cc,2);

%% simulation
% initialzie
e0 = soc0*E;
e = e0;
b = zeros(size(D));
s = zeros(size(D));
o = zeros(size(D));
t = 1;
% start from each hour
for h = 1:nH
  
  if ~isSimple % use bidding policy result for proposed method
    r = C(h)*D((1:H)+H*(h-1));
  else % provide all 10 MW capacity always
    r = B*D((1:H)+H*(h-1));
  end
  
  % small offset for maintaining energy balance
  Doff = max(e0-e,0)/eta;
  % calculate penalty price from market clearing results
  pi = delta * uL(h) / (uR*T);
  % the optimal SoC threshold
  uH = (1/(m*alpha)) * ((( eta^2+1 )/(eta*R))*pi)^(1/(m-1));
  % current max and current min, reset at each hour
  eMax = e;
  eMin = e;
  % go through steps in the hour
  for n = 1:H
    if ~isSimple % use optimal control policy
      [c, p, eMax, eMin] = CycleController2(uH, e,r(n)+Doff,eMax, eMin, eta, T, [], E);
    else % use simple policy
      [c, p] = SimpleController(r(n)+Doff, e, eta, T, E);
    end
    % update soc
    e = e + T*c*eta - T*p/eta;
    % record everything
    s(t) = e/E;
    b(t) = c-p;
    o(t) = Doff;
    t = t+1;
  end
  % calculate performance for this hour
  [~, rhoA, rhoD, rhoP] = ...
    PJMPerScrSim(r,b((1:H)+H*(h-1))-o((1:H)+H*(h-1)),T*3600);
  rhoM(h) = (rhoA+rhoD+rhoP)/3;
  rhoMA(h) = rhoA;
  rhoMD(h) = rhoD;
  rhoMP(h) = rhoP;
end

% market revenue
lambda = CCP + mRatio.*PCP;
if ~isSimple
  rev = C.*lambda.*rhoM;
  rev(C<1) = 0;
else
  rev = B.*lambda.*rhoM;
end
rev(rhoM < rhoMin) = 0;
rev(isnan(rev)) = 0;

% calculate degradation
rf = rainflow(sig2ext(s));
deg = sum(R*E*alpha*rf(3,:).*(rf(1,:)*2).^m);

