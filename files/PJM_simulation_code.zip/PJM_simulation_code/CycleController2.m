function [c, p, eMax, eMin] = CycleController2(delta, e,r,eMaxPrev, eMinPrev, eta, T, ef, E)
%%
% Title: Cycle Controller
% Author: Bolun Xu
% Date: 2017-2-10
% Summary: The controller modulate all response cycles below delta
% Inputs:
%   delta - the maximum cycle depth
%   e - current SoC
%   r - response signal
%   eMaxPrev - before maximum SoC
%   eMinPrev - before minimum SoC
% Outputs:
%   c - charge power
%   p - discharge power
%   eMax - current maximum SoC
%   eMin - current minimum SoC
%%

% E = 1; % MWh
eUp = E*0.95; % upper SoC limit
eDn = E*0.1;  % lower SoC limit
% T = 10/3600;   % time step in hours
eta_c = eta;  % charge efficiency
eta_p = eta;  % discharge efficiency

eMax = max(e, eMaxPrev);
eMin = min(e, eMinPrev);

if isempty(ef)
eUpg = min(eUp, eMin + E*delta);
eDng = max(eDn, eMax - E*delta);
elseif ef > 0
    eUpg = min(eUp, max(eMin + E*delta, ef));
    eDng = max(eDn, eMax - E*delta);
else
    eUpg = min(eUp, eMin + E*delta);
    eDng = max(eDn, min(eMax - E*delta, -ef));
end
    
    

if r >= 0
  c = min( (eUpg-e)/(T*eta_c), r);
  p = 0;
else
  c = 0;
  p = min( (e-eDng)*(eta_p/T), -r);
end


