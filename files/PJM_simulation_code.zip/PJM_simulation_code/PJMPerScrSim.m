function [rho, rhoA, rhoD, rhoP] = PJMPerScrSim(r,b,T)
%%
% Simple PJM Performance Score Calculator
% Inputs
%   r - regulation instructions
%   b - response
%   T - time interval in seconds
% Outputs
%   rho - performance score
%   rhoA - accuracy score
%   rhoD - delay score
%   rhoP - precision score

rho = zeros(floor(length(r)/(3600/T)),1);
rhoA = rho;
rhoD = rho;
rhoP = rho;
N =3600/T; % number of samples per hour

for i = 1:length(rho)
  rhoD(i) = 1; % no delay for BES
  % hourly instruction
  rH = r((i-1)*N + (1:N));
  % hourly response
  bH = b((i-1)*N + (1:N));
  % correlation score
  rhoA(i) = corr(rH,bH);
  % percision score
  rhoP(i) = 1-sum(abs(rH-bH))/sum(abs(rH));
  % rhoP(i) = max(1-mean(abs(rH-bH))/abs(mean(rH)), 0);
end

rho = (rhoA + rhoD + rhoP)/3;