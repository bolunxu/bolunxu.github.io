This is the Matlab Code for the battery degradation model proposed in this paper. The main function is batDegModel.m.

Copy right @ Bolun Xu, I will provide no warrenty for this code.