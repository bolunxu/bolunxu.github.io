function [D,n,pOut,eOut] = simPolicyDis(theta, xi, N, eta, P, E, e0, c, Q)
%%
% Simulation the storage operation policy 
% Author: Bolun Xu
% Contact: https://bolunxu.github.io/
% Inputs:
%   theta - energy marginal value for simulation
%   xi - net demand series
%   T - net demand duration
%   eta - efficiency
%   P - power rating
%   E - energy rating
%   e0 - initial energy
%   c - system marginal cost sets
%   Q - set of cummulative segment quantities

%%

% initialization
% Pn = zeros(N,1);
% En = zeros(N,1);

% find the segment to discharge
% add small number 1e-6 to compensate digit error
k = find(c >= (theta/eta-1e-6), 1, 'first');
if isempty(k)
    n = N;
    return;
end
% find the segment to charge
m = find(c < theta*eta, 1, 'last');
if isempty(m)
    m = 0;
    % q = -inf*ones(size(c));
else
    % q = Q(m+1,:)-Q(m+0,:);
end

% get the charge and discharge comment for storage
pD = (xi-Q(k,:)').*((xi-Q(k,:)')>0);
pC = (xi-Q(m+1,:)').*((xi-Q(m+1,:)')<0);


pD(pD>P) = P;
pD(pD<0) = 0;

pC(pC>0) = 0;
pC(pC<-P) = -P;

p = pD+pC;
pE = pD/eta+pC*eta;

e = e0 - cumsum(pE);

% simulate control until reach SoC bounds
for n = 1:N
    
    if e(n) > E
        D = 1;
        pOut = p(1:n);
        e(n) = E;
        eOut = e(1:n);
        return;
    elseif e(n) < 0
        D = -1;
        pOut = p(1:n);
        e(n) = 0;
        eOut = e(1:n);
        return;
    end
    
end

% format output
thetaN = 2*(E-e(N));
if theta == thetaN
    D = 0;
    pOut = p(1:n);
    eOut = e(1:n);
    return;
elseif theta > thetaN
    D = 1;
    pOut = p(1:n);
    eOut = e(1:n);
    return;
else
    D = -1;
    pOut = p(1:n);
    eOut = e(1:n);
    return;
end