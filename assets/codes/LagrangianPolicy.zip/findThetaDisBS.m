function [theta, n, p, e] = findThetaDisBS(xi, N, eta, P, E, e0, c, Q)
% Bi-section search algorithm


%%
R = max(c)/eta; % upper search bound
L = 0; % lower search bound

theta = (R+L)/2;


while (R-L) > 1e-3 % error below 1e-3
    theta = (R+L)/2; % set a value for theta
    
    % simulate the SoC and return 
    %   D - higher (D>0) or lower (D<0) guess of theta value
    %   n - time step simulated 
    %   p - power output series til n
    %   e - SoC output series til n
    [D,n,p,e] = simPolicyDis(theta, xi, N, eta, P, E, e0, c, Q);
    
    if D > 0 % if guessed too high, reduce upper bound
        R = theta;
    elseif D < 0 % if guessed too low, increase lower bound
        L = theta;
    else
        return;
    end
    
end