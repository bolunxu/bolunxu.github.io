main function is main.m

need CVX for Matlab and Gurobi to perform benchmark optimization

contact: Bolun Xu, bx2177@columbia.edu