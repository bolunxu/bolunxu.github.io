%%
% Title: Look-ahead control test for energy storage 
% Author: Bolun Xu
% Website: bolunxu.github.io
% Summary:
% Reference:
%


%% generate piecewise linear objective function

N = 100; % time stpes
J = 1000; % number of segments for each step

% generate cost (c) and quantity (Q) for each segment
c = (sort(normrnd(0,rand(1,1)*5,J,1))+20)';
Q = zeros(J,N);
for n = 1:N
Q(:,n) = cumsum(rand(J,1))*(rand(1,1)/2 + .5);
Q(1,n) = 0;
Q(:,n) = Q(:,n)*20/max(Q(:,n));
end


xi = rand(N,1)*10+5; % operating point (net load)


%% storage parameter
P = 1; % storage power rating
E = 4; % storage energy rating
eta = .92; % efficiency
e0 = E/2; % initial SoC

%% run proposed algortihm policy
tic;    
[thetaOut, n, pOut, eOut] = findThetaDisBS(xi, N, eta, P, E, e0, c, Q);
tOut = toc;
p1Out = pOut(1);

%% run benchmark optimization with CVX and gurobi
tic;
[thetaOpt, pOpt, eOpt] = findThetaDisOpt(xi, N, eta, P, E, e0, c, Q);
tOpt = toc;
p1Opt = pOpt(1);


