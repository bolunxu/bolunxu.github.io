function [thetaOut, pOut, eOut] = findThetaDisOpt(xi, N, eta, P, E, e0, c, Q)
%% 
% Title: Find the marignal energy value at e0 for given scenario using
%   optimization
% Note: requrie CVX
% Author: Bolun Xu
% Contact: https://bolunxu.github.io/
% Inputs:
%   xi - net demand series
%   T - net demand duration
%   eta - efficiency
%   P - power rating
%   E - energy rating
%   e0 - initial energy
%   c - system marginal cost sets
%   Q - set of cummulative segment quantities
%   J - size of c and Q
%   Theta - set of all potential marginal costs (size is 2J)



%% optimization

J = numel(c);

cvx_begin
cvx_solver gurobi
    variable g(N,J) nonnegative
    variable e(N)  nonnegative
    variable C(N)
    variable pC(N) nonnegative
    variable pD(N) nonnegative
    dual variable theta
    
    % minimize total generation cost
    minimize(sum(C) + (E-e(N))^2)
    
    subject to
    % generation segment logic
    for j = 1:(J-1)
    	g(1:N,j) <= (Q(j+1,1:N)-Q(j,1:N))'
    end
    % storage power and energy rating
    e <= E
    pC <= P
    pD <= P
    
    % generation cost for each segment
    C == g * c'
    
    % soc evolution constraint
    for n = 2:N
        e(n)-e(n-1) == -pD(n)/eta + pC(n)*eta
    end
    theta : e(1)-e0 == -pD(1)/eta + pC(1)*eta
    
    % net demand serving constraint
    sum(g,2)+pD-pC >= xi
   
    
cvx_end

thetaOut = -theta;
pOut = pD-pC;
eOut = e;


