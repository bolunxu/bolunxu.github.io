using JuMP
using Gurobi
using MAT
using Printf
# using CSV
# using DataFrames
# using Plots
# using JLD

# High-level Settings
Zone = "NYC" # price zone name

# read price
fileln = matopen(string("./data/RTP_",Zone,"_2010_2019.mat"))
RTP = read(fileln, "RTP")
close(fileln)
# fileln = string("./data/RTP_",Zone,"_2010_2019.csv")
# RTP = DataFrame(CSV.File(fileln))
# RTP= RTP[:, 2:end];

#

J = 5;

E = 1;  # storage energy capacity in MWh

BatType = 1

if BatType == 0
    Ncyc = [7700 7200 6400]; # LFP
elseif BatType == 1
    Ncyc = [2200 1600 400]; # NMC
else
    Ncyc = [1400 600 350]; # NCA
end


R = 150e3;

EEseg = [0.2 0.4 0.4];

cc_pu = zeros(1,3);
cc_pu[1] = 5*R*0.2/Ncyc[1];
cc_pu[2] = 5*R*(0.2/Ncyc[2]*sum(EEseg[1:2]) - 0.2/Ncyc[1]*EEseg[1])/EEseg[2];
cc_pu[3] = 5*R*(0.2/Ncyc[3]*sum(EEseg[1:3]) - 0.2/Ncyc[2]*sum(EEseg[1:2]))/EEseg[3];


c_pu = zeros(1,5)
c_pu[1] = cc_pu[3]
c_pu[2] = cc_pu[2]
c_pu[3] = cc_pu[1]
c_pu[4] = cc_pu[2]
c_pu[5] = cc_pu[3]

Eseg = [.2 .2 .2 .2 .2]

# c_pu[2] = c_pu[1]
# c_pu[3] = c_pu[1]
# c_pu = c_pu[3]
# Eseg = 1
# simulation setting
T = 288; # time step per day
M = 1/12; # duaration per step in hour
N_sim = 3650; # number of days
L = RTP[:,1];

Lp = L .> 0

# BES setting
P = .5; # power rating MW
# E = 2; # energy rating MWh
eta = .9; # single-trip efficiency
e0 = .5 * E;
ef = e0;

# initialize optimization model
model = Model(Gurobi.Optimizer)
set_silent(model) # no outputs
# total discharge power
@variable(model, p_d[1:T, 1:J], lower_bound = 0 )
# charge segments
@variable(model, p_c[1:T, 1:J], lower_bound = 0  )
# energy level segments
@variable(model, e_b[1:T, 1:J], lower_bound = 0  )
# initial energy level segments
@variable(model, e_i[1:J], lower_bound = 0  )
# SoC binaries
@variable(model, u[1:T,1:J], Bin)
# total discharge power
@variable(model, d[1:T])
# total charge power
@variable(model, c[1:T])
# total energy level
@variable(model, e[1:T])
@variable(model, D) # incremental cycle degradation
@variable(model, C) # value of battery capacity at the end of operation
@variable(model, R) # market revenue

# arbitrage revenue
@constraint(model, ArbRev, R == M*sum(L.*(d-c)) )
# degradation increments
# piece-wise linear degradation opportunity value
@constraint(model, DegCost, C == M*sum(c_pu.*sum(p_d, dims = 1) )  )
# initial SoC evolution
@constraint(model, SoCInit[j = 1:J], e_b[1,j] - e_i[j] == M*(p_c[1,j] - p_d[1,j]) )
# rest SoC evolution
@constraint(model, SoCCont[t = 2:T, j = 1:J], e_b[t,j] - e_b[t-1,j] == M*(p_c[t,j] - p_d[t,j]) )
# discharge power segment logic
@constraint(model, DisSeg[t=1:T], d[t] == sum(p_d[t,:]) * eta )
# charge power segment logic
@constraint(model, ChrSeg[t=1:T], c[t] == sum(p_c[t,:]) / eta )
# SoC segment logic
@constraint(model, SoCSeg[t=1:T], e[t] == sum(e_b[t,:])  )
# initial energy level
@constraint(model, Eneinit, sum(e_i) == e0 )
# final energy level
@constraint(model, Enelast, e[T] >= ef )
# max discharge power
@constraint(model, DisMax[t=1:T], d[t] <= P )
# max charge power
@constraint(model, ChrMax[t=1:T], c[t] <= P )
# max energy level
@constraint(model, SoCMax[t=1:T, j = 2:J], e_b[t,j] <= E*Eseg[j]*u[t,j-1] )
# max energy level
@constraint(model, SoCMax1[t=1:T, j = 1], e_b[t,j] <= E*Eseg[j] )
# minimum energy level
@constraint(model, SoCMin[t=1:T, j = 1:J], e_b[t,j] >= E*Eseg[j]*u[t,j] )
# warranty constraint
# @constraint(model, ETHMax, M*sum(d)/eta <= E-E*D0 )
# warranty constraint
# @constraint(model, ETHMax, M*sum(d)/eta <= E-E*D0 )

# maximize revenue plus degradation value
@objective(model, Max, R-C)



# initialize
R_s = zeros(1, N_sim)
P_s = zeros(1, N_sim)
C_s = zeros(1, N_sim)
D_s = zeros(1, N_sim)
e_S = zeros(T, N_sim)
c_S = zeros(T, N_sim)
d_S = zeros(T, N_sim)

@printf("Optimization starts...\n")
@time begin
for n = (N_sim-364):(N_sim)


# update prices
local L = RTP[:,n]
local Lp = L .> 0

# update prices in constraints
for t = 1:T
    set_normalized_coefficient(ArbRev, d[t], -M*L[t] )
    set_normalized_coefficient(ArbRev, c[t], M*L[t] )
    set_normalized_rhs(DisMax[t], P*Lp[t])
end


optimize!(model)

global R_s[n] = value(R)# objective_value(model);

global C_s[n] = value(C)
global P_s[n] = value(R)-value(C)
global D_s[n] = sum(value.(d))
global e_S[:,n] = value.(e)
global d_S[:,n] = value.(d)
global c_S[:,n] = value.(c)
# termination_status(model)
@printf("Finished Day %d, Cum Rev %d, Cum Profit %d, Cum Cost %d, OptStatus: %s \n", n, sum(R_s), sum(P_s), sum(C_s), termination_status(model))


end
end

# FN = @sprintf("H%d_L%d_P%d_Ben", E, EoL*100, P_recycle/1e4)
#
#
file = matopen(string("./results_arb/",Zone,"_NMC_Bin.mat"), "w")
# write(file, "D_s", collect(D_s))
write(file, "E", E)
write(file, "P", P)
write(file, "eta", eta)
write(file, "J", J)
write(file, "e", vec(e_S))
write(file, "c", vec(c_S))
write(file, "d", vec(d_S))
# write(file, "Ycal", Ycal)
# write(file, "P_recycle", P_recycle)
# write(file, "Vs0", Vs0)
# write(file, "EoL", EoL)
# write(file, "EoW", EoW)
close(file)

# save(string(pwd(), "\\results_jl\\",Zone,"2010_2019_",FN,".jld"), "Vs", Vs, "Ds", Ds, "P", P, "E", E)



# end
