% How to create a simple lattice
clc ; clear all ; close all ;
rng(100); % To avoid some issues with linprog

% number of stages
H = 24;

% number of scenarios at each stage
S = 50;

% storage parameter
sPara.P = .5;
sPara.E = 1;
sPara.eta = .9;
sPara.c = 0;
sPara.e0 = .5;
sPara.ef = .0;

% import price
load('NYC2018_RT.mat')
load('NYC2018.mat')

L = DALMP(31*24 + (1:H));


DA = reshape(repmat(DALMP, 1, 12)', 12*numel(DALMP), 1); % day-ahead price
RT = RTLMP(1:numel(DA)); % real-time price

Diff = RT-DA; % DA-RT bias

I = repmat(0:11,1,365)' + reshape(repmat((1:288:numel(DA))', 1, 12)', numel(DA)/24, 1);

D = zeros(numel(DA)/24, 24);

for h = 1:24
   D(:,h) = Diff(I + (h-1)*12); % price bias samples for each hour
end

D = D(1:(12*31),:);

%% perform benchmark SDDP solver, need FAST and GUROBI
% S nodes per H stage
lattice = Lattice.latticeEasy(H, S);

% Run SDDP
params = sddpSettings('algo.McCount',25,...
                      'stop.pereiraCoef',0.1,...
                      'stop.iterationMax',20,...
                      'verbose',1,...
                      'algo.minTheta',-1e3,...
                      'solver','gurobi') ;
var.x = sddpVar(2,H) ;
var.s = sddpVar(1,H) ;
lattice = lattice.compileLattice(@(scenario)storage_arbitrage_nlds(scenario, var, H, L, D, sPara),params) ; 

output = sddp(lattice, params) ;
plotOutput(output);

%% run proposed algorithm
ed = .01; % SoC granularity
% initialize final value function
vEnd = zeros(101,1); 
vEnd(1:51) = 0e3;
Ne = numel(vEnd);
v = zeros(Ne,H+1);
v(:,end) = vEnd;

tic;
for t = H:-1:1 % run backwards in time
    vi = v(:,t+1); % read last value function
    vo = CalcValue(L(t) + D(1:S,t), sPara.c, sPara.P, sPara.eta, vi, ed);
    v(:,t) = vo; % same current value function
end
tS = toc;


%% forward path test
profitS = zeros(20,1);
profitF = zeros(20,1);

for i = 1:100

% generate a forward path
fPath = lattice.randomPath();
% execute forward path using FAST
[~,~,~,solution] = forwardPass(lattice,fPath, params) ; 
% retrive solution
xVal = lattice.getPrimalSolution(var.x, solution);
pF = xVal(1,:)'-xVal(2,:)';

% simulate using calculated value function
eF = zeros(H,1);
eS = zeros(H,1);
pS = eS;
e = sPara.e0;
ee = e;
% start simulation
for t = 1:H
   vv = v(:,t+1);
   ee = ee - pF(t).*(pF(t)>0)/sPara.eta - pF(t).*(pF(t)<=0)*sPara.eta;
   [e, p] =  Arb_Value(L(t) + D(fPath(t),t), vv, e, sPara.P, sPara.E, sPara.eta, sPara.c, size(v,1));
   eS(t) = e;
   pS(t) = p;
   eF(t) = ee;
end

% retrieve price data
Price = L+D(sub2ind(size(D), fPath, (1:H)'));

% calculate profit for this scenario
profitS(i) = sum(pS.*Price);
profitF(i) = sum(pF.*Price);

end
%%
figure('Position', [200 200 600 200])
hold all
plot(pS*2, '-.s', 'LineWidth', 2)
plot(pF*2, '-d', 'LineWidth', 1.5)
grid on
xlabel('Timestep', 'FontSize', 12)
ylabel('Storage power [p.u.]')
xlim([1 H])
legend('Proposed', 'SDDP', 'FontSize', 12, 'Location', 'best')