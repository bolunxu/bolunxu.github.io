run arbitrage_test.m

need FAST SDDP tool box: https://stanford.edu/~lcambier/cgi-bin/fast/index.php 
and Gurobi to run benchmark solver

contact: Bolun Xu, bx2177@columbia.edu
