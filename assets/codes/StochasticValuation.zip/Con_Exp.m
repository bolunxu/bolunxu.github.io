function E = Con_Exp(a,b,d)
%%
% probability integration between a and b (a <= b)

%%
E1 = sum(d(:)' .* ((d(:)'-b(:)) <= 0),2);

E2 = sum(d(:)' .* ((d(:)'-a(:)) < 0),2);

E = (E1-E2)/numel(d);