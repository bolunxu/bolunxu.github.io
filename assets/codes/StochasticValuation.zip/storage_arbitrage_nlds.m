function [cntr, obj] = storage_arbitrage_nlds(scenario, var, H, L, D, sPara)

x = var.x; % x(1,:) for discharge, x(2,:) for charge
s = var.s;
t = scenario.getTime();
i = scenario.getIndex();

P = sPara.P;
E = sPara.E;
etaC = sPara.eta;
etaD = 1/etaC;
c = sPara.c;
e0 = sPara.e0;
ef = sPara.ef;

price = L(t) + D(i,t);

obj = - price * (x(1,t)-x(2,t)) + c*x(1,t);
cntr1 = x(:,t) >= 0; % charge and discharge power greater than zero
cntr2 = x(2,t) <= P; % charge power less than P
cntr3 = x(1,t) <= P * (price >= 0); % discharge power less than P if price is positive
cntr4 = s(:,t) >= 0; % SoC >= 0
cntr5 = s(:,t) <= E; % SoC <= E
% cntr7 = s(:,H) >= ef;

if (t == 1)
    cntr6 = s(:,t) == e0 + x(2,t)*etaC - x(1,t)*etaD;
elseif (t>1 && t<=H)
    cntr6 = s(:,t) == s(:,t-1) + x(2,t)*etaC - x(1,t)*etaD;
end

cntr = [cntr1 cntr2 cntr3 cntr4 cntr5 cntr6];