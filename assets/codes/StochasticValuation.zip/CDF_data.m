function F = CDF_data(x,d)
%% 

F = sum((d(:)'-x(:)) <= 0,2)/numel(d);
