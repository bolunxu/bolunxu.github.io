compTime = [218.8 458.1 582.2 2274.4 3145];
compPro = [17.5 18.1 20.8 21.5 22.7];
scenarios = [10 30 50 80 100];
ProfitS = [281.6 346.9 356.0 552.1 511.54];
ProfitF = [281.7 348.7 355.4 551.6 511.46];

figure('Position', [200 200 600 200])
hold all
plot(scenarios, compTime/60, '-s', 'LineWidth', 2)
grid on
xlabel('Price samples per stage', 'FontSize', 12)
ylabel('Solution time [min]', 'FontSize', 12)

figure('Position', [200 200 600 200])
hold all
plot(scenarios, compPro, '-s', 'LineWidth', 2)
grid on
xlabel('Price samples per stage', 'FontSize', 12)
ylabel('Solution time [ms]', 'FontSize', 12)

figure('Position', [200 200 600 200])
hold all
plot(scenarios, ProfitS, '-s', 'LineWidth', 1.5)
plot(scenarios, ProfitF, ':s', 'LineWidth', 2)
grid on
xlabel('Price samples per stage', 'FontSize', 12)
ylabel('Average objective value', 'FontSize', 12)
legend('Proposed', 'SDDP', 'FontSize', 12, 'Location', 'best')